package com.mycompany.invoise.invoiseweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvoiseWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
